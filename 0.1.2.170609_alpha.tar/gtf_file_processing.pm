#!/usr/bin/perl
package gtf_file_processing;

use strict;
use warnings;

### This is the gtf_file_processing.pm, which function as the lib of gtf_rd287.pl.
# Script to read the input gtf file (default input is genes.gtf) and get some statistical data
# according to the flags. The different request will be done by different subroutines stored here.
# Following the instructions given in HW2 B part.
# Tim(Rui Deng) 12/04/2017 [last modified Tim(Rui Deng) 22/04/17]

### This subroutine will do the -g flag work, which is counting the number of genes in the gtf file.
sub get_result_g {
    unless ( -f "$_[0]" ) {
        print "File not exist:$!\n";
        exit;
    }
    my %hash1;    # Key is the gene_id.
    my $g_cnt;
	my $reg='\s+\S+\s\S+\s+\d+\s+\d+\s+\S\s+\S\s+\S';
	# Or use 'exon' instead of the first '\S+' for a gene should have at least
	# one exon.
    open( IN, "<", "$_[0]" ) || die "cannot open the file: $!\n";

    while (<IN>) {    # Use while rather than foreach to save the space.
           # Use the regular expression to get the information in the input file
           # (which is about 30% faster than using the split).
           # Using "$ time perl gtf_rd287.pl -e" in terminal.
        if ( $_ =~/^\S+$reg\s+gene_id\s"(\S+)";\s+/ ) {
            $hash1{$1} =1; 
			# Use hash set to count the number of gene with different name.
        }

    }
    close IN;    # Close the infile after using.
    $g_cnt = keys %hash1
      ;    # Get the number of keys in the hash, which is the number of genes.
    return $g_cnt;    # Return the number of genes.
}

### This subroutine will do the -e flag work, which is counting the number of exons in the gtf file.
sub get_result_e {
    unless ( -f "$_[0]" ) {
        print "File not exist:$!\n";
        exit;
    }
	my $e_cnt = 0;
	my $reg='\s+\S+\sexon\s+\d+\s+\d+\s+\S\s+\S\s+\S';
    open( IN, "<", "$_[0]" ) || die "cannot open the file: $!\n";
    

    while (<IN>) {    # Use while rather than foreach to save the space.

        # Use the regular expression to get the information in the input file
        # (which is about 30% faster than using the split).
        # Using "$ time perl gtf_rd287.pl -e" in terminal.
        if ( $_ =~/^\S+$reg\s+gene_id\s"\S+";\s+/ ) {
            $e_cnt++;    # Count the number of all exons.
        }

    }
    close IN;            # Close the infile after using.

    return $e_cnt;       # Return the number of exons.
}

### This subroutine will do the -a flag work, which is calculating the average exon length.
sub get_result_a {
    unless ( -f "$_[0]" ) {
        print "File not exist:$!\n";
        exit;
    }
    open( IN, "<", "$_[0]" ) || die "cannot open the file: $!\n";
    my $e_cnt   = 0;
    my $sum_e_l = 0;
    my %ligate;
    my $s_for_ligate;
	my $reg='\s+\S+\sexon\s+(\d+)\s+(\d+)\s+\S\s+\S\s+\S';
    while (<IN>) {    # Use while rather than foreach to save the space.

        # Use the regular expression to get the information in the input file
        # (which is about 30% faster than using the split).
        # Using "$ time perl gtf_rd287.pl -a" in terminal.
        if ( $_ =~/^\S+$reg\s+gene_id\s"\S+";\s+/ ) {
      # Count the number of the exons.
      # Calculate the sum of the exon length.
      # The length of each exon is calculate by the substruct of two coordinate.
      # Use the abs() to ensure the sum length works.
            $s_for_ligate = "$2" . "$1";
            unless ( exists $ligate{$s_for_ligate} ) {

                #$e_cnt++;
                $sum_e_l += abs( $2 - $1 ) + 1;
            }
            $ligate{$s_for_ligate} = 1;

        }

    }
    close IN;    # Close the infile after using.

    # If there is no exon, this program will end with no numerical result.
    $e_cnt = keys %ligate;
    if ( $e_cnt == 0 ) {
        die "There is no exon, so there is no answer for the average length.\n";
    }

    #my $check=keys %ligate;
    #if ($e_cnt == $check){print"!\n";} else {print "?\n";}
    my $avg = $sum_e_l / $e_cnt;    # Calculate the average exon length.
    return $avg;                    # Return the average exon length.
}

#################
sub get_result_b {
    unless ( -f "$_[0]" ) {
        print "File not exist:$!\n";
        exit;
    }

    #my $e_cnt= 0;
    open( IN, "<", "$_[0]" ) || die "cannot open the file: $!\n";

    #my $sum_e_l=0;
    my @array;
    my %ligate;
    my $s_for_ligate;
    my $length;
    my $avg;
	my $reg='\s+\S+\sexon\s+(\d+)\s+(\d+)\s+\S\s+\S\s+\S';
    while (<IN>) {    # Use while rather than foreach to save the space.

        # Use the regular expression to get the information in the input file
        # (which is about 30% faster than using the split).
        # Using "$ time perl gtf_rd287.pl -a" in terminal.
        if ( $_ =~/^\S+$reg\s+gene_id\s"\S+";\s+/ )   {
      # Count the number of the exons.
      # Calculate the sum of the exon length.
      # The length of each exon is calculate by the substruct of two coordinate.
      # Use the abs() to ensure the sum length works.
            $s_for_ligate = "$2" . "$1";
            unless ( exists $ligate{$s_for_ligate} ) {

                #$sum_e_l += abs( $2 - $1 )+1;
                push( @array, abs( $2 - $1 ) + 1 );

                #$e_cnt++;
            }
            $ligate{$s_for_ligate} = 1;

        }

    }
    close IN;    # Close the infile after using.

    # If there is no exon, this program will end with no numerical result.
    #if ( $e_cnt == 0 ) {
    #	die "There is no exon, so there is no answer for the average length.\n";
    #}

    $length = ( $length = @array ) - 1;
    if ( $length == -1 ) {
        die "There is no exon, so there is no answer for the average length.\n";
    }
    $avg = $array[0];
    unless ( $length == 0 ) {    #unless there is only one exon.
        for ( 1 .. $length ) {
            $avg += ( $array[$_] - $avg ) / ( $_ + 1 );
        }
    }

    #my $avg = $sum_e_l / $e_cnt; # Calculate the average exon length.
    return $avg;                 # Return the average exon length.
}

### This subroutine will do the -n flag work,
# which is reporting the gene with the highest number of exons.
sub get_result_n {
    unless ( -f "$_[0]" ) {
        print "File not exist:$!\n";
        exit;
    }
    open( IN, "<", "$_[0]" ) || die "cannot open the file: $!\n";
    my %hash1;    # Key(name of gene), Value (the number of exons of that gene).
    my $highest_num_e      = 0;
    my %id_gene_with_h_n_e = ();
    my $tmp_h_cnt          = 0;
    my %ligate;
    my $s_for_ligate;
	my $reg='\s+\S+\sexon\s+(\d+)\s+(\d+)\s+\S\s+\S\s+\S';

    while (<IN>) {    # Use while rather than foreach to save the space.

        # Use the regular expression to get the information in the input file
        # (which is about 30% faster than using the split).
        # Using "$ time perl gtf_rd287.pl -n" in terminal.
        if ( $_ =~/^\S+$reg\s+gene_id\s"(\S+)";\s+/ ) {
            $s_for_ligate = "$2" . "$1";
            unless ( exists $ligate{$s_for_ligate} ) { $hash1{$3}++; }
            $ligate{$s_for_ligate} = 1;

            # The number of exons of that gene.

           # if you do not care whether there are several genes share
           # the same maximum number of exons:
           # if ($maxnumber < $hash1{$2}) {$maxnumber = $hash1{$2}; $maxname=$2;
        }

    }

    close IN;    # Close the infile after using.

# Find which key(or keys) has the maxmium value,(which gene(or genes) has highest number of exons).
# This progress will take a little bit longer time than just found one gene with the highest
# number with exons.
    foreach ( keys(%hash1) ) {

        if ( $highest_num_e < $hash1{$_} ) {
            $highest_num_e      = $hash1{$_}; # get the highest number of exons.
            %id_gene_with_h_n_e = ();
            $tmp_h_cnt          = 0;
            $id_gene_with_h_n_e{ $tmp_h_cnt++ } = $_;
        }
        elsif ( $highest_num_e == $hash1{$_} )
        {    # if several genes share the highest number.
            $id_gene_with_h_n_e{ $tmp_h_cnt++ } = $_; # use array to store them.
        }

    }

    # If there is no exon, this program will end here.
    if ( $highest_num_e == 0 ) {
        die "There is no exon in this file.\n";
    }

    # The ids with thehighest number of exons.
    my @ids_gene_with_h_n_e = values %id_gene_with_h_n_e;
    print "@ids_gene_with_h_n_e";
    my $referenced_ids_gene_with_h_n_e =
      \@ids_gene_with_h_n_e;    # Reference the array.

# Return the names of genes with the highest number of exons(referenced) and that highest number.
    return ( $referenced_ids_gene_with_h_n_e, $highest_num_e );

# if you do not care whether there are several genes share the same maximum number of exons:
#return ($maxname,$maxnumber );

}

sub get_result_p {
    unless ( -f "$_[0]" ) {
        print "File not exist:$!\n";
        exit;
    }
    open( IN, "<", "$_[0]" ) || die "cannot open the file: $!\n";
    my $e_cnt_1 = 0;

    #my $sum_e_l;
    my %ligate;
    my $s_for_ligate;
	my $reg='\s+\S+\sexon\s+(\d+)\s+(\d+)\s+\S\s+\S\s+\S';
    while (<IN>) {    # Use while rather than foreach to save the space.

        # Use the regular expression to get the information in the input file
        # (which is about 30% faster than using the split).
        # Using "$ time perl gtf_rd287.pl -a" in terminal.
        if ( $_ =~/^\S+$reg\s+gene_id\s"\S+";\s+/ ) {
      #$e_cnt++; # Count the number of the exons.
      # Calculate the sum of the exon length.
      # The length of each exon is calculate by the substruct of two coordinate.
      # Use the abs() to ensure the sum length works.
            $s_for_ligate = "$2" . "$1";
            unless ( exists $ligate{$s_for_ligate} ) { $e_cnt_1++; }
            $ligate{$s_for_ligate} = 1;

        }

    }
    close IN;    # Close the infile after using.

    return $e_cnt_1;    # Return the number of exons.
}

sub get_result_l {
    unless ( -f "$_[0]" ) {
        print "File not exist:$!\n";
        exit;
    }
    open( IN, "<", "$_[0]" ) || die "cannot open the file: $!\n";
    my $sum_g_l = 0;
    my $sum_e_l = 0;
    my $percent = -1;

    #my $sum_e_l;
    my %gene;

    my $s_for_ligate;
    my %ligate;
	my $reg='\s+\S+\s(\S+)\s+(\d+)\s+(\d+)\s+\S\s+\S\s+\S';
    while (<IN>) {    # Use while rather than foreach to save the space.

        # Use the regular expression to get the information in the input file
        # (which is about 30% faster than using the split).
        # Using "$ time perl gtf_rd287.pl -a" in terminal.
        if ( $_ =~/^\S+$reg\s+gene_id\s"(\S+)";\s+/ ) {
      #$e_cnt++; # Count the number of the exons.
      # Calculate the sum of the exon length.
      # The length of each exon is calculate by the substruct of two coordinate.
      # Use the abs() to ensure the sum length works.
      #$s_for_ligate="$2"."$1";
            if ( $1 eq 'start_codon' ) {
                if   ( $3 > $2 ) { $gene{$4}[0] = $2; }
                else             { $gene{$4}[0] = $3; }
            }
            if ( $1 eq 'stop_codon' ) {
                if   ( $3 > $2 ) { $gene{$4}[1] = $3; }
                else             { $gene{$4}[1] = $2; }
            }
            if ( $1 eq 'exon' ) {
                $s_for_ligate = "$3" . "$2";
                unless ( exists $ligate{$s_for_ligate} ) {

                    #$e_cnt++;
                    $sum_e_l += abs( $3 - $2 ) + 1;
                }
                $ligate{$s_for_ligate} = 1;

            }

        }

    }

    close IN;    # Close the infile after using.
    foreach ( keys(%gene) ) {
        $sum_g_l += abs( $gene{$_}[1] - $gene{$_}[0] ) + 1;
    }
    unless ( $sum_g_l == 0 ) { $percent = $sum_e_l / $sum_g_l; }
    return $percent * 100;    # Return the number of exons.
}

#################
sub get_result_m {
    unless ( -f "$_[0]" ) {
        print "File not exist:$!\n";
        exit;
    }

    #my $e_cnt= 0;
    my %gene;
    my $sum_g_l = 0;
    open( IN, "<", "$_[0]" ) || die "cannot open the file: $!\n";

    #my $sum_e_l=0;
    my @array;

    #my %ligate;
    #my $s_for_ligate;
    my $length;
    my $avg;
	my $reg='\s+\S+\s(\S+)\s+(\d+)\s+(\d+)\s+\S\s+\S\s+\S';
    while (<IN>) {    # Use while rather than foreach to save the space.

        # Use the regular expression to get the information in the input file
        # (which is about 30% faster than using the split).
        # Using "$ time perl gtf_rd287.pl -a" in terminal.
        if ( $_ =~/^\S+$reg\s+gene_id\s"(\S+)";\s+/)        {
      #$e_cnt++; # Count the number of the exons.
      # Calculate the sum of the exon length.
      # The length of each exon is calculate by the substruct of two coordinate.
      # Use the abs() to ensure the sum length works.
      #$s_for_ligate="$2"."$1";
            if ( $1 eq 'start_codon' ) {
                if   ( $3 > $2 ) { $gene{$4}[0] = $2; }
                else             { $gene{$4}[0] = $3; }
            }
            if ( $1 eq 'stop_codon' ) {
                if   ( $3 > $2 ) { $gene{$4}[1] = $3; }
                else             { $gene{$4}[1] = $2; }
            }

        }

    }

    close IN;    # Close the infile after using.

    #foreach (keys (%gene)) {$sum_g_l+=abs($gene{$_}[1]-$gene{$_}[0])+1;}
    foreach ( keys(%gene) ) {
        push( @array, abs( $gene{$_}[1] - $gene{$_}[0] ) + 1 );
    }

    #my $gene_cnt = keys %gene;
    # gene_cnt++;
    # If there is no exon, this program will end with no numerical result.
    #if ( $gene_cnt == 0 ) {
    #	die "There is no gene, so there is no answer for the average length.\n";
    #}

    # avoid the overflow problem.
    $length = ( $length = @array ) - 1;

    if ( $length == -1 ) {
        die "There is no exon, so there is no answer for the average length.\n";
    }
    $avg = $array[0];
    unless ( $length == 0 ) {    #unless there is only one gene.
        for ( 1 .. $length ) {
            $avg += ( $array[$_] - $avg ) / ( $_ + 1 );
        }
    }

    #my $avg = $sum_g_l / $gene_cnt; # Calculate the average exon length.
    return $avg;                 # Return the average gene length.
}

#################
sub get_result_s {
    unless ( -f "$_[0]" ) {
        print "File not exist:$!\n";
        exit;
    }
    my $gene_name = $_[1];

    #my $e_cnt= 0;
    #my %gene;
    my $gene_length;
    open( IN, "<", "$_[0]" ) || die "cannot open the file: $!\n";

    my $sum_e_l = 0;

    #my @array;
    my %ligate;
    my $s_for_ligate;

    #my $length;
    my $lines   = 0;
    my $start   = -1;
    my $end     = -1;
    my $max_cds = -1;
    my %cds;
	my $reg='\s+\S+\s(\S+)\s+(\d+)\s+(\d+)\s+(\S)\s+(\S)\s+(\S)';
    while (<IN>) {    # Use while rather than foreach to save the space.

        # Use the regular expression to get the information in the input file
        # (which is about 30% faster than using the split).
        # Using "$ time perl gtf_rd287.pl -a" in terminal.
        if ( $_ =~/^\S+$reg\s+gene_id\s"$gene_name";\s+/ ) {
      #$e_cnt++; # Count the number of the exons.
      # Calculate the sum of the exon length.
      # The length of each exon is calculate by the substruct of two coordinate.
      # Use the abs() to ensure the sum length works.

            if ( $1 eq 'start_codon' ) {
                if   ( $3 > $2 ) { $start = $2; }
                else             { $start = $3; }
            }
            if ( $1 eq 'stop_codon' ) {
                if   ( $3 > $2 ) { $end = $3; }
                else             { $end = $2; }
            }
            if ( $1 eq 'exon' ) {
                $s_for_ligate = "$3" . "$2";
                unless ( exists $ligate{$s_for_ligate} ) {

                    #$e_cnt++;
                    $sum_e_l += abs( $3 - $2 ) + 1;
                }
                $ligate{$s_for_ligate} = 1;

            }
            if ( $1 eq 'CDS' ) {
                $s_for_ligate          = "$3" . "-" . "$2";
                $cds{$s_for_ligate}[0] = $4;                    # score
                $cds{$s_for_ligate}[1] = $5;                    # -/+ strand
                $cds{$s_for_ligate}[2] = $6;                    # cds number
                $cds{$s_for_ligate}[3] = abs( $3 - $2 ) + 1;    # cds length
            }
            $lines++;

            #print "there is\n";
        }

    }

    close IN;    # Close the infile after using.
    if ( $lines == 0 ) { print "the input gene is not there.\n"; exit; }
    else {
        if ( $start == -1 || $end == -1 ) {
            print "miss information\n";
            $gene_length = -1;
        }
        else { $gene_length = abs( $end - $start ) + 1; }
        my $number_exon = keys %ligate;
        my $percent     = 100 * $sum_e_l / $gene_length;

      #foreach (keys (%gene)) {push (@array,abs($gene{$_}[1]-$gene{$_}[0])+1);}
      #my $gene_cnt = keys %gene;
      # gene_cnt++;
      # If there is no exon, this program will end with no numerical result.
      #if ( $gene_cnt == 0 ) {
      #	die "There is no gene, so there is no answer for the average length.\n";
      #}
        print "there is $lines lines about the input gene.\n";
        print "it has $number_exon exons\n";
        unless ( $gene_length == -1 ) {
            print "the length of this input gene is $gene_length\n";

            printf(
                "the proportion of the length_exon/length_gene is %4.2f%%\n",
                $percent );
        }
        my $cds_n = keys %cds;
        unless ( $cds_n == 0 ) {
            print "It has $cds_n CDSs\n";
            foreach ( keys %cds ) {
                if ( $cds{$_}[3] >= $max_cds ) { $max_cds = $cds{$_}[3]; }
                print "The coordinate is $_\n";
                print "The socre is $cds{$_}[0]\n";
                print "The strand is $cds{$_}[1]\n";
                print "The cds number is $cds{$_}[2]\n";
                print "The cds length is $cds{$_}[3]\n";
            }
            print "The longest cds is $max_cds\n";
        }
        ########
        # why there is some gene has exon out of range?? Such as Sox17
        # cds and ORF?
        ######
    }
    return 1;    # Return for successfully execute.
}

1;

