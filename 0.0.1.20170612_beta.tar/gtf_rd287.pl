#!/usr/bin/perl

use strict;
use warnings;

### This is the gtf_rd287.pl, which will use the lib gtf_file_processing.pm.
# Script to read the input gtf file (default input is genes.gtf) and get some statistical data
# according to the flags. The different request will be done by different subroutines stored in
# the lib gtf_file_processing.pm file.
# Following the instructions given in HW2 B part.
# Tim(Rui Deng) 12/04/2017 [last modified Tim(Rui Deng) 12/06/17]



use lib "./";
use gtf_file_processing;
use Getopt::Std;
use vars
  qw($opt_g $opt_e $opt_a $opt_n $opt_h $opt_b $opt_l $opt_m $opt_s $opt_t);
getopts('geanhblmst');
my $usage = "
wrong input,(should be [-g,-e,-a,-n,-h,-b,-l,-m,-s,-t]) . 
Use -h for some helpful instructions.\n
";
my $detailedusage = "
Usage: gtf_rs206.pl [options]\noptions: [-g,-e,-a,-n,-h,-b,-l,-m,-s,-t] 
filename (optional) genename[-s only]
The reporting of results is directed by these flags: 
Reports the number of [g]enes in the gtf file.[-g] 
Reports the number of [e]xons.[-e] 
Reports the [a]verage exon length. [-a]
Reports the gene with the highest [n]umber of exons. [-n]
Do the average calculate avoiding data overflow with a [b]righer algorithm. [-b]
Calculate the proportion between total [l]ength of exon/ total [l]ength of gene. [-l]
Reports the [m]ean number of gene length avoiding data overflow. [-m]
[S]earch the information of the query gene name agains the infile [-s]
Get the number of [t]ranscripts  [-t]
";
my $filename = 'genes.gtf';    # default input name.


unless ( $opt_g || $opt_e || $opt_a || $opt_n || $opt_h || $opt_b || $opt_l
  || $opt_m || $opt_s || $opt_t ) {
    die $usage;
}

# -h for printing out some helpful instructions.
if ($opt_h) {
    print "$detailedusage\n";
    exit;
}
my $choice1;    # Choice for whether change the inputfile.

# If the user input the inputfile name in command argument, use that file.
if ( exists $ARGV[0] ) {
    if ( $ARGV[0] =~ /\.gtf$/ ) {
        $filename = $ARGV[0];
    }
    else {
        print "File in wrong format.\n";
        exit;
    }
}
else {
    # Ask the user if they want to change the input name.
    print "Do you want to change the default input file ($filename)?\n";
    do {
        print "\n\tPlease type Y/N.\n";
        $choice1 = <STDIN>;
        chomp($choice1);
      } until ( $choice1 eq 'Y' || $choice1 eq 'N' )
      ;    # Keep asking until getting 'Y' or 'N'.
    if ( $choice1 eq 'Y' ) {
        do {
            print "type the new name.(ending with .gtf)\n";
            print "There are the candidate file names:\n\n\t";
            system("ls *.gtf");
            $filename = <STDIN>;
            chomp($filename);    # get the file name of the new inputfile.
          } until ( $filename =~ /\.gtf$/ )
          ;    # Keep asking until get the name of inputfile in right format.
        print "Change the new input file name to $filename\n";
    }
}

my ($t_cnt,$g_cnt,$e_cnt,$sum_g_l,$sum_e_l,$hashref_g_e_cnt) = 
		&gtf_file_processing::get_result_basic($filename);

### Do the task according to the flags.

# -g for reporting the number of genes in the gtf file.
if ($opt_g) {
 printf( "number of genes\t: %4.0f\n", $g_cnt);
}

# -e for reporting the number of exons.
if ($opt_e) {
 	printf( "number of exons\t: %4.0f\n", $e_cnt );
}

# -t for reporting the number of transcripts.
if ($opt_t) {
    printf( "number of transcripts\t: %4.0f\n",
        $t_cnt );
}

# -a for reporting the average exon length.
if ($opt_a) {
	printf( "average exon length\t= %4.2f\n", $sum_e_l/$e_cnt );
}

# -b for brighter way of reporting the average exon length.
if ($opt_b) {
    printf( "average exon length\t= %4.2f\n",
        &gtf_file_processing::get_result_b($filename) );
}


# -l for calculating the percent of the total length of exon/gene
if ($opt_l) {
    printf( "The percent of the total length of exon/gene\t: %4.2f%%\n",
        100*$sum_e_l/$sum_g_l);
}

# -n for reporting the genes (could report several ) with the highest number
# of exons.
if ($opt_n) {
    my $highest_num_e      = 0; 
    my %id_gene_with_h_n_e = ();
    my $tmp_h_cnt          = 0; 


	my %hash_g_e_cnt=%{$hashref_g_e_cnt}; #dereferenced the refhash.
    foreach ( keys %hash_g_e_cnt ) {

        if ( $highest_num_e < $hash_g_e_cnt{$_} ) {
            $highest_num_e      = $hash_g_e_cnt{$_}; # get the highest number of exons.


            %id_gene_with_h_n_e = ();
				 
            $tmp_h_cnt          = 0;
            $id_gene_with_h_n_e{ $tmp_h_cnt++ } = $_;
        }
        elsif ( $highest_num_e == $hash_g_e_cnt{$_} )
        {    # if several genes share the highest number.
            $id_gene_with_h_n_e{ $tmp_h_cnt++ } = $_; # use array(the value of the hash) to store them.
        }

    }


    # If there is no exon, this program will end here.
    if ( $highest_num_e == 0 ) {
        die "There is no exon in this file.\n";
    }

    # The ids with thehighest number of exons.
    my @ids_gene_with_h_n_e = values %id_gene_with_h_n_e;

    print "highest numbers of exons:\t$highest_num_e\n";

    # Print the names(1 to many) of gene who has the highest number of exons.
    # Dereference the array and print each element there.
    foreach ( @ids_gene_with_h_n_e ) {
        print "id of that gene:\t$_\n";
    }

}





# -m calculate the mean length of gene in a algorithm with less risk of 
# dataoverflow.
if ($opt_m) {
    printf( "average gene length\t= %4.2f\n",
        &gtf_file_processing::get_result_m($filename) );
}

# -s flag: retrive the input gene and ouput the result in
# "<input file>_<input gene>.out" file.
# Search the information of the query gene name agains the infile.
if ($opt_s) {
    unless ( $ARGV[1] ) { print "you should input the gene name.\n"; exit; }

    &gtf_file_processing::get_result_s( $filename, $ARGV[1] );
    print "The information is in $filename"."_$ARGV[1].out file\n";
}



