#!/usr/bin/perl
package gtf_file_processing;

use strict;
use warnings;

### This is the gtf_file_processing.pm, which function as the lib of gtf_rd287.pl.
# Script to read the input gtf file (default input is genes.gtf) and get some statistical data
# according to the flags. The different request will be done by different subroutines stored here.
# Following the instructions given in HW2 B part and its feedback as well as mini-project.
# Tim(Rui Deng) 12/04/2017 [last modified Tim(Rui Deng) 12/06/17]

### This subroutine will do several flag works at the same time, which is counting the number of exons in the gtf file.
sub get_result_basic {
    unless ( -f "$_[0]" ) {
        print "File not exist:$!\n";
        exit;
    }
	my %hash_t; # Used for calculating unique number of transcripts.
	my %hash_g; # Used for calculating unique number of genes.
	my %hash_e; # Used for calculating unique number of exons.
	my %hash_g_e_cnt; # Used for counting exons of different genes.

	# Start (value [0]) and stop (value [1]) coordinate of that gene 
	# (name as the key).
	my %hash_g_c; 

	# Used for avoding calculating the same exon (with the same coordinate)
	# mutiple times.
	my $exon_id;
 
	my $sum_e_l; # The totle length of all exons.
	my $sum_g_l; # The totle length of all genes.
	my $reg='\s+\S+\s(\S+)\s+(\d+)\s+(\d+)\s+\S\s+\S\s+\S';
 	open( IN, "<", "$_[0]" ) || die "cannot open the file: $!\n";
    while (<IN>) {    # Use while rather than foreach to save the space.

        # Use the regular expression to get the information in the input file
        # (which is about 30% faster than using the split).
	    # Some lines didnt have p_id content in its attribute part.
        if ( $_ =~/^\S+$reg\s+gene_id\s"(\S+)";\s+gene_name\s+"\S+";\s+p_id\s+"\S+";\s+transcript_id\s+"(\S+)";/ 
			|| $_ =~/^\S+$reg\s+gene_id\s"(\S+)";\s+gene_name\s+"\S+";\s+transcript_id\s+"(\S+)";/ ) { 


			$hash_g{$4}=1; # Use the hash_g to count the genes.
			$hash_t{$5}=1; # Use the hash_t to count the transcrits.

			if ($1 eq'exon'){
	            $exon_id = "$3" . "$2"; # Be overlapped each loop.
           		unless ( exists $hash_e{$exon_id} ) {
					# The length of each exon is calculate by the substruct of two coordinate.
                	# Use the abs() to ensure the sum length works.
					$sum_e_l += abs( $3 - $2 ) + 1;
				
            		# Count the exons of that gene.
					$hash_g_e_cnt{$4}++;
					##########################################################
           			# If you do not care whether there are several genes share
           			# the same maximum number of exons:
           			# if ($maxnumber < $hash_g_e_cnt{$4}) {
					# $maxnumber = $hash_g_e_cnt{$4}; $maxname=$4;}
					##########################################################
            	}
            	$hash_e{$exon_id} = 1;# Use the hash_e to count the exons.
			} 
              
			# Choice two smaller number as the coordinate then plus 3 rather
			# than using the smaller one of start and bigger one of end then
			# plus 1 to avoid mistake, for many of the genes is on reverse
			# strand. For example, if there is a gene, which has start codon
			# at 11 to 13 and stop codon at 1 to 3. If we choice the smaller
			# coordinate of start(11) and bigger coordinate of stop(3), the
			# result will be abs(3 - 11) + 1 = 9 rather than the right one, which is
			# abs(1 - 11) + 3 = 13. 
            if ( $1 eq 'start_codon' ) {
                if   ( $3 > $2 ) { $hash_g_c{$4}[0] = $2; }
                else             { $hash_g_c{$4}[0] = $3; }
            }

            if ( $1 eq 'stop_codon' ) {
                if   ( $3 > $2 ) { $hash_g_c{$4}[1] = $2; }
                else             { $hash_g_c{$4}[1] = $3; }
            }        

		}
    }
	
    close IN;    # Close the infile after using.
	my $t_cnt=keys %hash_t;		  # Count the number of the transcripts.
	my $g_cnt=keys %hash_g;		  # Count the number of the genes.
    my $e_cnt=keys %hash_e;       # Count the number of the exons.
    #if ( $e_cnt == 0 ) {
    #    die "There is no exon, so there is no answer for the average length.\n";
    #}
	
	# Calculate the total length of all genes.
    foreach ( keys(%hash_g_c) ) {
        $sum_g_l += abs( $hash_g_c{$_}[1] - $hash_g_c{$_}[0] ) + 3;
    }
    #my $avg = $sum_e_l / $e_cnt;    # Calculate the average exon length.

	# Return 5 scalers and 1 hashref.
    return ($t_cnt,$g_cnt,$e_cnt,$sum_g_l,$sum_e_l,\%hash_g_e_cnt);       
}




# Brighter way to avoiding data overflow when do the average exons length,
# especially useful for really big inputfile.
sub get_result_b {
    unless ( -f "$_[0]" ) {
        print "File not exist:$!\n";
        exit;
    }


    my @array;
    my %ligate;
    my $s_for_ligate;
    my $length;
    my $avg;
	my $reg='\s+\S+\sexon\s+(\d+)\s+(\d+)\s+\S\s+\S\s+\S'; # Used latter.
    open( IN, "<", "$_[0]" ) || die "cannot open the file: $!\n";
    while (<IN>) {    # Use while rather than foreach to save the space.

        # Use the regular expression to get the information in the input file
        # (which is about 30% faster than using the split).
        # Using "$ time perl gtf_rd287.pl -a" in terminal.
        if ( $_ =~/^\S+$reg\s+gene_id\s"\S+";\s+/ )   {
      
	  # Stroe each exon length in the array for latter calculation.
      # The length of each exon is calculate by the substruct of two coordinate.
      # Use the abs() to ensure the sum length works.
            $s_for_ligate = "$2" . "$1";
            unless ( exists $ligate{$s_for_ligate} ) {
                push( @array, abs( $2 - $1 ) + 1 );
            }
            $ligate{$s_for_ligate} = 1;

        }

    }
    close IN;    # Close the infile after using.



    $length = @array;
    if ( $length == 0 ) {
        die "There is no exon, so there is no answer for the average length.\n";
    }
    $avg = $array[0];
    unless ( $length <= 1 ) {    #unless there is only one exon.
        for ( 1 .. $length-1 ) {
            $avg += ( $array[$_] - $avg ) / ( $_ + 1 );
        }
    }
    return $avg;                 # Return the average exon length.
}



# Do the -m flag works.
# Reports the [m]ean number of gene length, avoding the data overflow.
sub get_result_m {
    unless ( -f "$_[0]" ) {
        print "File not exist:$!\n";
        exit;
    }

    #my $e_cnt= 0;
    my %gene;
    my $sum_g_l = 0;
    open( IN, "<", "$_[0]" ) || die "cannot open the file: $!\n";

    #my $sum_e_l=0;
    my @array;

    #my %ligate;
    #my $s_for_ligate;
    my $length;
    my $avg;
	my $reg='\s+\S+\s(\S+)\s+(\d+)\s+(\d+)\s+\S\s+\S\s+\S';
    while (<IN>) {    # Use while rather than foreach to save the space.

        # Use the regular expression to get the information in the input file
        # (which is about 30% faster than using the split).
        # Using "$ time perl gtf_rd287.pl -a" in terminal.
        if ( $_ =~/^\S+$reg\s+gene_id\s"(\S+)";\s+/)        {
      #$e_cnt++; # Count the number of the exons.
      # Calculate the sum of the exon length.
      # The length of each exon is calculate by the substruct of two coordinate.
      # Use the abs() to ensure the sum length works.
      #$s_for_ligate="$2"."$1";

# Ensure choice the smaller two coordinate to do the calculate later.
            if ( $1 eq 'start_codon' ) {
                if   ( $3 > $2 ) { $gene{$4}[0] = $2; }
                else             { $gene{$4}[0] = $3; }
            }
            if ( $1 eq 'stop_codon' ) {
                if   ( $3 > $2 ) { $gene{$4}[1] = $2; }
                else             { $gene{$4}[1] = $3; }
            }

        }

    }

    close IN;    # Close the infile after using.

# Calculate the totele length of the genes.
    foreach ( keys(%gene) ) {
        push( @array, abs( $gene{$_}[1] - $gene{$_}[0] ) + 3 );
    }

    #my $gene_cnt = keys %gene;
    # gene_cnt++;
    # If there is no exon, this program will end with no numerical result.
    #if ( $gene_cnt == 0 ) {
    #	die "There is no gene, so there is no answer for the average length.\n";
    #}

    # avoid the overflow problem. 
	# Get the length of the array.
    $length = @array;


	# Report and exit when there is nothing in the array.
    if ( $length == 0 ) {
        die "There is no exon, so there is no answer for the average length.\n";
    }
    $avg = $array[0]; # assign it with the first element first.
    unless ( $length <= 1 ) {    # If there is only one gene, the average is the first one length.
		# Use this algorithm to calculate the average length of genes to avoid data overflow.	        
		for ( 1 .. $length-1 ) {
            $avg += ( $array[$_] - $avg ) / ( $_ + 1 );
        }
    }
	
    # my $avg = $sum_g_l / $gene_cnt; # Calculate the average exon length in a simple way.
    return $avg;                 # Return the average gene length.
}

# Do the -s flag works, retrive the input gene and ouput the result in
# "<input gtf file>_<input gene>.out" file.
# Search the information of the query gene name agains the infile.
sub get_result_s {
    unless ( -f "$_[0]" ) {
        print "File not exist:$!\n";
        exit;
    }
    my $gene_name = $_[1];

   
    my $gene_length;
    open( IN, "<", "$_[0]" ) || die "cannot open the file: $!\n";
	open( OUT, ">", "$_[0]"."_$_[1].out" ) || die "cannot open the file: $!\n";

    my $sum_e_l = 0;

    
    my %ligate;
    my $s_for_ligate;

    
    my $lines   = 0;
    my $start   = -1;
    my $end     = -1;
    my $max_cds = -1;
    my %cds;
	my %transcript;

	my $reg='\s+\S+\s(\S+)\s+(\d+)\s+(\d+)\s+(\S)\s+(\S)\s+(\S)';
    while (<IN>) {    # Use while rather than foreach to save the space.

        # Use the regular expression to get the information in the input file
        # (which is about 30% faster than using the split).
        # Using "$ time perl gtf_rd287.pl -a" in terminal.
        if ( $_ =~/^\S+$reg\s+gene_id\s+"$gene_name";\s+gene_name\s+"\S+";\s+p_id\s+"\S+";\s+transcript_id\s+"(\S+)";/ 
			||  $_ =~/^\S+$reg\s+gene_id\s+"$gene_name";\s+gene_name\s+"\S+";\s+transcript_id\s+"(\S+)";/) {
	  # some lines didnt have p_id content in its attribute part.

     
      # Calculate the sum of the exon length.
      # The length of each exon is calculate by the substruct of two coordinate.
      # Use the abs() to ensure the sum length works.

            if ( $1 eq 'start_codon' ) {
                if   ( $3 > $2 ) { $start = $2; }
                else             { $start = $3; }
            }
            if ( $1 eq 'stop_codon' ) {
                if   ( $3 > $2 ) { $end = $2; }
                else             { $end = $3; }
            }
            if ( $1 eq 'exon' ) {
                $s_for_ligate = "$3" . "$2";
                unless ( exists $ligate{$s_for_ligate} ) {

                    #$e_cnt++;
                    $sum_e_l += abs( $3 - $2 ) + 1;
                }
                $ligate{$s_for_ligate} = 1;

            }
            if ( $1 eq 'CDS' ) {
                $s_for_ligate          = "$3" . "-" . "$2";
                $cds{$s_for_ligate}[0] = $4;                    # score
                $cds{$s_for_ligate}[1] = $5;                    # -/+ strand
                $cds{$s_for_ligate}[2] = $6;                    # cds number
                $cds{$s_for_ligate}[3] = abs( $3 - $2 ) + 1;    # cds length
            }
			$transcript{$7}=1;

            $lines++;


        }

    }

    close IN;    # Close the infile after using.
    if ( $lines == 0 ) { print "The input gene is not there.\n"; exit; }
    else {
        if ( $start == -1 || $end == -1 ) {
            print "Miss information\n";
            $gene_length = -1;
        }
        else { $gene_length = abs( $end - $start ) + 3; }
        my $number_exon = keys %ligate;
        my $percent     = 100 * $sum_e_l / $gene_length;
		my $number_transcript=keys %transcript;
      #foreach (keys (%gene)) {push (@array,abs($gene{$_}[1]-$gene{$_}[0])+1);}
      #my $gene_cnt = keys %gene;
      # gene_cnt++;
      # If there is no exon, this program will end with no numerical result.
      #if ( $gene_cnt == 0 ) {
      #	die "There is no gene, so there is no answer for the average length.\n";
      #}
        print OUT "There is $lines lines about the input gene.\n";
        print OUT "It has $number_exon exons\n";
		print OUT "It has $number_transcript transcripts.\n";
		foreach (keys %transcript){print OUT "The transcript id is $_\n";}
        unless ( $gene_length == -1 ) { 
		# -1 is the default score, if the gene_length is still -1, means 
		# there is no start codon and stop codon data of that gene, which
		# is rare but still exist.
            print OUT "The length of this input gene is $gene_length\n";
            printf OUT (
                "The proportion of the length_exon/length_gene is %4.2f%%\n",
                $percent );
        }
        my $cds_n = keys %cds;# get the number of cds.
        unless ( $cds_n == 0 ) {
            print OUT "It has $cds_n CDSs\n";
            foreach ( keys %cds ) {
                if ( $cds{$_}[3] >= $max_cds ) { $max_cds = $cds{$_}[3]; }
                print OUT "\nThe coordinate is $_\n";
                print OUT "The socre is $cds{$_}[0]\n";
                print OUT "The strand is $cds{$_}[1]\n";
                print OUT "The cds number is $cds{$_}[2]\n";
                print OUT "The cds length is $cds{$_}[3]\n";
            }
            print OUT "The longest cds is $max_cds bp long.\n";
        }

    }
	close OUT;
    return 1;    # Return for successfully execute.
}

1;

